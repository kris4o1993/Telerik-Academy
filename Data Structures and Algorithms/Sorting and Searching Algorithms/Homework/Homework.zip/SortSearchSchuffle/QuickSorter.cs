﻿namespace SortSearchSchuffle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class QuickSorter<T> : ISorter<T> where T : IComparable<T>
    {
        public void Sort(IList<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("The collection is null!");
            }

            if (collection.Count < 2)
            {
                return;
            }

            this.QuickSort(collection, 0, collection.Count - 1);
        }

        private void QuickSort(IList<T> collection, int start, int end)
        {
            int left = start;
            int right = end;
            int middle = left;
            T pivot = collection[middle];

            do
            {
                while (pivot.CompareTo(collection[left]) > 0)
                {
                    left++;
                }

                while (pivot.CompareTo(collection[right]) < 0)
                {
                    right--;
                }

                if (left < right)
                {
                    this.SwapByIndex(collection, left, right);
                    left++;
                    right--;
                }
                else
                {
                    if (left == right)
                    {
                        left++;
                        right--;
                    }
                    else
                    {
                        break;
                    }
                }

            } while (left < right);

            if (start < right)
            {
                this.QuickSort(collection, start, right);
            }

            if (left < end)
            {
                this.QuickSort(collection, left, end);
            }
        }

        private void SwapByIndex(IList<T> collection, int firstIndex, int secondIndex)
        {
            T tempValue = collection[firstIndex];
            collection[firstIndex] = collection[secondIndex];
            collection[secondIndex] = tempValue;
        }
    }
}