﻿namespace SortSearchSchuffle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class MergeSorter<T> : ISorter<T> where T : IComparable<T>
    {
        public void Sort(IList<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("The collection is null!");
            }

            if (collection.Count < 2)
            {
                return;
            }

            this.MergeSort(collection, 0, collection.Count - 1);
        }

        public void MergeSort(IList<T> collection, int start, int end)
        {
            if (start < end)
            {
                int middle = (start + end) / 2;
                this.MergeSort(collection, start, middle);
                this.MergeSort(collection, middle + 1, end);

                T[] leftArray = new T[middle - start + 1];
                T[] rightArray = new T[end - middle];

                Array.Copy(collection.ToArray(), start, leftArray, 0, middle - start + 1);
                Array.Copy(collection.ToArray(), middle + 1, rightArray, 0, end - middle);

                int left = 0, right = 0;
                for (int current = start; current < end + 1; current++)
                {
                    if (left == leftArray.Length)
                    {
                        collection[current] = rightArray[right];
                        right++;
                    }
                    else if (right == rightArray.Length)
                    {
                        collection[current] = leftArray[left];
                        left++;
                    }
                    else if (leftArray[left].CompareTo(rightArray[right]) < 0)
                    {
                        collection[current] = leftArray[left];
                        left++;
                    }
                    else
                    {
                        collection[current] = rightArray[right];
                        right++;
                    }
                }
            }
        }
    }
}
