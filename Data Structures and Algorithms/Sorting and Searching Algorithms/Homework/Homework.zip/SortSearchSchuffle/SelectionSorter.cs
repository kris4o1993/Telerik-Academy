﻿namespace SortSearchSchuffle
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class SelectionSorter<T> : ISorter<T> where T : IComparable<T>
    {
        public void Sort(IList<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("The collection is null!");
            }
            
            if (collection.Count < 2)
            {
                return;
            }

            this.SelectionSort(collection);
        }

        private void SelectionSort(IList<T> collection)
        {
            for (int index = 0; index < collection.Count - 1; index++)
            {
                int minValueIndex = this.FindMinValueIndex(collection, index);
                if (collection[index].CompareTo(collection[minValueIndex]) > 0)
                {
                    this.SwapByIndex(collection, index, minValueIndex);
                }
            }
        }

        private int FindMinValueIndex(IList<T> collection, int startIndex)
        {
            int minValueIndex = startIndex;

            for (int index = startIndex + 1; index < collection.Count; index++)
            {
                if (collection[index].CompareTo(collection[minValueIndex]) < 0)
                {
                    minValueIndex = index;
                }
            }

            return minValueIndex;
        }

        private void SwapByIndex(IList<T> collection, int firstIndex, int secondIndex)
        {
            T tempValue = collection[firstIndex];
            collection[firstIndex] = collection[secondIndex];
            collection[secondIndex] = tempValue;
        }
    }
}
