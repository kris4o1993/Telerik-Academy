﻿namespace SortSearchSchuffle
{
    using System;
    using System.Collections.Generic;

    public class SortableCollection<T> where T : IComparable<T>
    {
        private readonly IList<T> items;
        private readonly Random random = new Random();

        public SortableCollection()
        {
            this.items = new List<T>();
        }

        public SortableCollection(IEnumerable<T> items)
        {
            this.items = new List<T>(items);
        }

        public IList<T> Items
        {
            get
            {
                return this.items;
            }
        }

        public void Sort(ISorter<T> sorter)
        {
            sorter.Sort(this.items);
        }

        public bool LinearSearch(T item)
        {
            for (int i = 0; i < this.items.Count; i++)
            {
                if (this.items[i].CompareTo(item) == 0)
                {
                    return true;
                }
            }

            return false;
        }

        public bool BinarySearch(T item)
        {
            if (!this.IsSorted())
            {
                throw new InvalidOperationException("The collection is not sorted.");
            }

            int start = 0;
            int end = this.items.Count - 1;
            int middle = 0;

            while (start <= end)
            {
                middle = (start + end) / 2;

                if (this.items[middle].CompareTo(item) < 0)
                {
                    start = middle + 1;
                }
                else if (this.items[middle].CompareTo(item) > 0)
                {
                    end = middle - 1;
                }
                else if (this.items[middle].CompareTo(item) == 0)
                {
                    return true;
                }
            }

            return false;
        }

        public void Shuffle()
        {
            for (int index = this.items.Count - 1; index > 0; index--)
            {
                int current = random.Next(index + 1);
                this.SwapByIndex(current, index);
            }
        }

        public void PrintAllItemsOnConsole()
        {
            for (int i = 0; i < this.items.Count; i++)
            {
                if (i == 0)
                {
                    Console.Write(this.items[i]);
                }
                else
                {
                    Console.Write(" " + this.items[i]);
                }
            }

            Console.WriteLine();
        }

        public override string ToString()
        {
            return string.Join(", ", this.Items);
        }

        private void SwapByIndex(int firstIndex, int secondIndex)
        {
            T tempValue = this.items[firstIndex];
            this.items[firstIndex] = this.items[secondIndex];
            this.items[secondIndex] = tempValue;
        }

        private bool IsSorted()
        {
            for (int i = 0; i < this.Items.Count - 1; i++)
            {
                if (this.Items[i].CompareTo(this.Items[i + 1]) > 0)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
