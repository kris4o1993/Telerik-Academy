﻿namespace SortSearchSchuffle.Tests.CollectionGenerators
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class IntCollectionGeneratorTests
    {
        [TestMethod]
        public void NumersRangeTests()
        {
            IList<int> collection = IntCollectionGenerator.Random(10);

            for (int i = 0; i < collection.Count; i++)
            {
                if (int.MinValue > collection[i] && collection[i] > int.MaxValue)
                {
                    Assert.Fail();
                }
            }
        }

        [TestMethod]
        public void NumbersCountTest()
        {
            int count = 10;
            IList<int> collection = IntCollectionGenerator.Random(count);
            int actual = collection.Count;
            int expected = count;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void SortedCollectionTest()
        {
            int count = 10;
            IList<int> collection = IntCollectionGenerator.Sorted(count);

            for (int i = 0; i < collection.Count - 1; i++)
            {
                if (collection[i].CompareTo(collection[i + 1]) >= 0)
                {
                    Assert.Fail();
                }
            }
        }

        [TestMethod]
        public void ReversedCollectionTest()
        {
            int count = 10;
            IList<int> collection = IntCollectionGenerator.Reversed(count);

            for (int i = 0; i < collection.Count - 1; i++)
            {
                if (collection[i].CompareTo(collection[i + 1]) <= 0)
                {
                    Assert.Fail();
                }
            }
        }
    }
}
