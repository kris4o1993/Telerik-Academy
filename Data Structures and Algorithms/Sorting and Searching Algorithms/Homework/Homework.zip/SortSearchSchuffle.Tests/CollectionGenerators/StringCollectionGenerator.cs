﻿namespace SortSearchSchuffle.Tests.CollectionGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class StringCollectionGenerator
    {
        private const string Letters = "abcdefghijklmnopqrstuvwxyz";
        private const int MinWordLength = 3;
        private const int MaxWordLenght = 10;
        private static readonly Random random = new Random();

        public static IList<string> Random(int count)
        {
            IList<string> collection = new List<string>(count);

            for (int i = 0; i < count; i++)
            {
                collection.Add(GenerateWord(random.Next(MinWordLength, MaxWordLenght + 1)));
            }

            return collection;
        }

        public static IList<string> Sorted(int count)
        {
            IList<string> collection = Random(count).OrderBy(x => x).ToList();
            return collection;
        }

        public static IList<string> Reversed(int count)
        {
            IList<string> collection = Sorted(count).Reverse().ToList();
            return collection;
        }

        private static string GenerateWord(int length)
        {
            string word = string.Empty;

            for (int i = 0; i < length; i++)
            {
                word += Letters[random.Next(Letters.Length)];
            }

            return word;
        }
    }
}
