﻿namespace SortSearchSchuffle.Tests.CollectionGenerators
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class StringCollectionGeneratorTests
    {
        [TestMethod]
        public void WordLengthTest()
        {
            int minLength = 3;
            int maxLength = 10;
            IList<string> collection = StringCollectionGenerator.Random(10);

            for (int i = 0; i < collection.Count; i++)
            {
                if (minLength > collection[i].Length && collection[i].Length > maxLength)
                {
                    Assert.Fail();
                }
            }
        }

        [TestMethod]
        public void WordsCountTest()
        {
            int count = 10;
            IList<string> collection = StringCollectionGenerator.Random(count);
            int actual = collection.Count;
            int expected = count;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void WordNullOfWhitespaceTest()
        {
            IList<string> collection = StringCollectionGenerator.Random(10);

            for (int i = 0; i < collection.Count; i++)
            {
                if (string.IsNullOrWhiteSpace(collection[i]))
                {
                    Assert.Fail();
                }
            }
        }

        [TestMethod]
        public void SortedCollectionTest()
        {
            int count = 10;
            IList<string> collection = StringCollectionGenerator.Sorted(count);

            for (int i = 0; i < collection.Count - 1; i++)
            {
                if (collection[i].CompareTo(collection[i + 1]) >= 0)
                {
                    Assert.Fail();
                }
            }
        }

        [TestMethod]
        public void ReversedCollectionTest()
        {
            int count = 10;
            IList<string> collection = StringCollectionGenerator.Reversed(count);

            for (int i = 0; i < collection.Count - 1; i++)
            {
                if (collection[i].CompareTo(collection[i + 1]) <= 0)
                {
                    Assert.Fail();
                }
            }
        }
    }
}
