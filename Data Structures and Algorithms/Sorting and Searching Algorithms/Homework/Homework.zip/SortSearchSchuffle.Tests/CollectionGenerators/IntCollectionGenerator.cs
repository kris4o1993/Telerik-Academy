﻿namespace SortSearchSchuffle.Tests.CollectionGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class IntCollectionGenerator
    {
        private static readonly Random random = new Random();

        public static IList<int> Random(int count)
        {
            IList<int> collection = new List<int>(count);

            for (int i = 0; i < count; i++)
            {
                collection.Add(random.Next(int.MinValue, int.MaxValue));
            }

            return collection;
        }

        public static IList<int> Sorted(int count)
        {
            IList<int> collection = Random(count).OrderBy(x => x).ToList();
            return collection;
        }

        public static IList<int> Reversed(int count)
        {
            IList<int> collection = Sorted(count).Reverse().ToList();
            return collection;
        }
    }
}
