﻿namespace SortSearchSchuffle.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class LinearSearchTests
    {
        private readonly SortableCollection<int> intCollection = new SortableCollection<int>(
            new int[] { 1231, -221, 320, -41221, 51231, 6987, -7, 81, -9000 });

        [TestMethod]
        public void SearchNonExistingItemTest()
        {
            int item = 100;
            Assert.IsFalse(this.intCollection.LinearSearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheBeginnigTest()
        {
            int item = 1231;
            Assert.IsTrue(this.intCollection.LinearSearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheMiddleTest()
        {
            int item = 51231;
            Assert.IsTrue(this.intCollection.LinearSearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheEndTest()
        {
            int item = -9000;
            Assert.IsTrue(this.intCollection.LinearSearch(item));
        }
    }
}