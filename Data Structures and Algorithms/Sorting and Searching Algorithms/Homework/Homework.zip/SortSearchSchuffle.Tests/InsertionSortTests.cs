﻿namespace SortSearchSchuffle.Tests
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using SortSearchSchuffle.Tests.CollectionGenerators;

    [TestClass]
    public class InsertionSortTests
    {
        private readonly ISorter<int> intSorter = new SelectionSorter<int>();
        private readonly ISorter<string> stringSorter = new SelectionSorter<string>();

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SortNullCollectionTest()
        {
            this.intSorter.Sort(null);
            this.stringSorter.Sort(null);
        }

        [TestMethod]
        public void SortRandomCollectionsTest()
        {
            int count = 100;
            IList<int> intCollection = IntCollectionGenerator.Random(count);
            this.intSorter.Sort(intCollection);
            Assert.IsTrue(IsSorted<int>(intCollection));

            IList<string> stringCollection = StringCollectionGenerator.Random(count);
            this.stringSorter.Sort(stringCollection);
            Assert.IsTrue(IsSorted<string>(stringCollection));
        }

        [TestMethod]
        public void SortSortedCollectionsTest()
        {
            int count = 100;
            IList<int> intCollection = IntCollectionGenerator.Sorted(count);
            this.intSorter.Sort(intCollection);
            Assert.IsTrue(IsSorted<int>(intCollection));

            IList<string> stringCollection = StringCollectionGenerator.Sorted(count);
            this.stringSorter.Sort(stringCollection);
            Assert.IsTrue(IsSorted<string>(stringCollection));
        }

        [TestMethod]
        public void SortReversedCollectionsTest()
        {
            int count = 100;
            IList<int> intCollection = IntCollectionGenerator.Reversed(count);
            this.intSorter.Sort(intCollection);
            Assert.IsTrue(IsSorted<int>(intCollection));

            IList<string> stringCollection = StringCollectionGenerator.Reversed(count);
            this.stringSorter.Sort(stringCollection);
            Assert.IsTrue(IsSorted<string>(stringCollection));
        }

        private static bool IsSorted<T>(IList<T> collection)
            where T : IComparable<T>
        {
            for (int i = 0; i < collection.Count - 1; i++)
            {
                if (collection[i].CompareTo(collection[i + 1]) > 0)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
