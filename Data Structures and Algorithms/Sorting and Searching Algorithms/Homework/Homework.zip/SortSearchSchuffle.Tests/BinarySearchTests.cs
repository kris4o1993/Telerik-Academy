﻿namespace SortSearchSchuffle.Tests
{
    using System;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class BinarySearchTests
    {
        private readonly SortableCollection<int> sortedIntCollection = new SortableCollection<int>(
            new int[] { -12, 0, 1, 1233, 2441, 35541, 566655, 7754432, 90122011 });

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void SearchInNotSortedCollection()
        {
            SortableCollection<int> notSortedIntCollection = new SortableCollection<int>(
            new int[] { 12, 0, 1, 1233, 2441, 35541, 566655, 7754432, 90122011 });

            int item = 0;
            notSortedIntCollection.BinarySearch(item);
        }

        [TestMethod]
        public void SearchNonExistingItemTest()
        {
            int item = 100;
            Assert.IsFalse(this.sortedIntCollection.BinarySearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheBeginnigTest()
        {
            int item = -12;
            Assert.IsTrue(this.sortedIntCollection.BinarySearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheMiddleTest()
        {
            int item = 35541;
            Assert.IsTrue(this.sortedIntCollection.BinarySearch(item));
        }

        [TestMethod]
        public void SearchExistingItemInTheEndTest()
        {
            int item = 90122011;
            Assert.IsTrue(this.sortedIntCollection.BinarySearch(item));
        }
    }
}